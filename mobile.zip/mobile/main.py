"""
CAIXA MESTRE MOBILE
===================
Aplicativo Android para gestão de almoxarifado com sincronização P2P.

Recursos:
- Banco SQLite local
- Sincronização automática entre dispositivos na mesma rede
- Até 5 dispositivos
- Funciona 100% offline
- UI otimizada para celular

Autor: Sistema CAIXA MESTRE
Versão: 1.0.0
"""

import os
import sys
import json
import sqlite3
import threading
import time
from datetime import datetime
from pathlib import Path

# Kivy imports
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.uix.progressbar import ProgressBar
from kivy.uix.spinner import Spinner
from kivy.uix.image import Image
from kivy.graphics import Color, Rectangle
from kivy.core.window import Window
from kivy.properties import StringProperty, ObjectProperty, BooleanProperty
from kivy.clock import Clock, mainthread
from kivy.network.urlrequest import UrlRequest
from kivy.utils import platform

# Importar telas do pacote screens
try:
    from screens.login_screen import LoginScreen
    from screens.dashboard_screen import DashboardScreen
    from screens.materiais_screen import MateriaisScreen
    from screens.busca_screen import BuscaScreen
    from screens.movimentacao_screen import MovimentacaoScreen
    from screens.detalhe_material_screen import DetalheMaterialScreen
    print("[IMPORT] Telas carregadas do pacote screens")
except ImportError as e:
    print(f"[IMPORT] Erro ao importar telas: {e}")
    # Fallback - usar classes internas (simplificadas)
    from kivy.uix.screen import Screen
    from kivy.uix.boxlayout import BoxLayout
    from kivy.uix.gridlayout import GridLayout
    from kivy.uix.scrollview import ScrollView
    from kivy.uix.label import Label
    from kivy.uix.button import Button
    from kivy.uix.textinput import TextInput

# Configurações globais
Window.clearcolor = (0.17, 0.24, 0.31, 1)  # Cor de fundo azul escuro


class DatabaseManager:
    """Gerenciador do banco SQLite local."""
    
    def __init__(self):
        self.db_path = self._get_db_path()
        self._init_database()
    
    def _get_db_path(self):
        """Retorna caminho do banco de dados baseado na plataforma."""
        if platform == 'android':
            from android.storage import app_storage_path
            return os.path.join(app_storage_path(), 'caixa_mestre.db')
        else:
            # Desktop (desenvolvimento)
            return 'caixa_mestre_mobile.db'
    
    def _init_database(self):
        """Inicializa schema do banco."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Tabela de materiais
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS materiais (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                codigo TEXT UNIQUE,
                nome TEXT NOT NULL,
                descricao TEXT,
                quantidade REAL DEFAULT 0,
                quantidade_minima REAL DEFAULT 0,
                unidade TEXT DEFAULT 'UN',
                localizacao TEXT,
                categoria TEXT,
                sync_version INTEGER DEFAULT 1,
                sync_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                deleted INTEGER DEFAULT 0
            )
        ''')
        
        # Tabela de movimentações
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS movimentacoes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tipo TEXT NOT NULL,  -- 'entrada', 'saida', 'ajuste'
                material_id INTEGER,
                quantidade REAL NOT NULL,
                responsavel TEXT,
                observacao TEXT,
                sync_version INTEGER DEFAULT 1,
                sync_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (material_id) REFERENCES materiais(id)
            )
        ''')
        
        # Tabela de sincronização
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sync_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                device_id TEXT,
                sync_type TEXT,
                records_synced INTEGER,
                sync_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status TEXT
            )
        ''')
        
        # Índices para performance
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_materiais_sync ON materiais(sync_timestamp)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_movimentacoes_sync ON movimentacoes(sync_timestamp)')
        
        conn.commit()
        conn.close()
    
    def get_connection(self):
        """Retorna conexão com o banco."""
        return sqlite3.connect(self.db_path)
    
    def get_materiais(self, busca=None, categoria=None):
        """Retorna lista de materiais."""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        query = "SELECT * FROM materiais WHERE deleted = 0"
        params = []
        
        if busca:
            query += " AND (nome LIKE ? OR codigo LIKE ? OR descricao LIKE ?)"
            params.extend([f'%{busca}%', f'%{busca}%', f'%{busca}%'])
        
        if categoria:
            query += " AND categoria = ?"
            params.append(categoria)
        
        query += " ORDER BY nome"
        
        cursor.execute(query, params)
        colunas = [desc[0] for desc in cursor.description]
        resultados = [dict(zip(colunas, row)) for row in cursor.fetchall()]
        
        conn.close()
        return resultados
    
    def add_material(self, dados):
        """Adiciona novo material."""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO materiais (codigo, nome, descricao, quantidade, 
                                   quantidade_minima, unidade, localizacao, categoria)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            dados.get('codigo'),
            dados['nome'],
            dados.get('descricao', ''),
            dados.get('quantidade', 0),
            dados.get('quantidade_minima', 0),
            dados.get('unidade', 'UN'),
            dados.get('localizacao', ''),
            dados.get('categoria', 'Geral')
        ))
        
        material_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return material_id
    
    def update_quantidade(self, material_id, quantidade, tipo='ajuste', responsavel=''):
        """Atualiza quantidade de material e registra movimentação."""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Atualizar material
        cursor.execute('''
            UPDATE materiais 
            SET quantidade = ?, sync_version = sync_version + 1,
                sync_timestamp = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (quantidade, material_id))
        
        # Registrar movimentação
        cursor.execute('''
            INSERT INTO movimentacoes (tipo, material_id, quantidade, responsavel)
            VALUES (?, ?, ?, ?)
        ''', (tipo, material_id, quantidade, responsavel))
        
        conn.commit()
        conn.close()
    
    def get_stats(self):
        """Retorna estatísticas rápidas."""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM materiais WHERE deleted = 0")
        total_materiais = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM materiais WHERE quantidade <= quantidade_minima AND deleted = 0")
        estoque_baixo = cursor.fetchone()[0]
        
        cursor.execute("SELECT SUM(quantidade) FROM materiais WHERE deleted = 0")
        total_itens = cursor.fetchone()[0] or 0
        
        conn.close()
        
        return {
            'total_materiais': total_materiais,
            'estoque_baixo': estoque_baixo,
            'total_itens': int(total_itens)
        }


class SyncManager:
    """Gerenciador de sincronização P2P."""
    
    def __init__(self, db_manager, device_id=None):
        self.db = db_manager
        self.device_id = device_id or self._generate_device_id()
        self.is_syncing = False
        self.peers = {}  # {ip: last_seen}
        self.server_thread = None
        self.running = False
    
    def _generate_device_id(self):
        """Gera ID único do dispositivo."""
        import uuid
        return str(uuid.uuid4())[:8]
    
    def start(self):
        """Inicia serviço de sincronização."""
        self.running = True
        # Iniciar thread de descoberta
        threading.Thread(target=self._discovery_loop, daemon=True).start()
        # Iniciar servidor HTTP para receber sync
        threading.Thread(target=self._start_server, daemon=True).start()
        print(f"[SYNC] Iniciado com ID: {self.device_id}")
    
    def stop(self):
        """Para serviço de sincronização."""
        self.running = False
    
    def _discovery_loop(self):
        """Loop de descoberta de dispositivos na rede."""
        import socket
        import struct
        
        # Configurar socket multicast para descoberta
        MCAST_GRP = '224.1.1.1'
        MCAST_PORT = 5007
        
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('', MCAST_PORT))
        
        mreq = struct.pack("4sl", socket.inet_aton(MCAST_GRP), socket.INADDR_ANY)
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
        sock.settimeout(1)
        
        while self.running:
            try:
                data, addr = sock.recvfrom(1024)
                msg = json.loads(data.decode())
                
                if msg.get('type') == 'discovery' and msg.get('device_id') != self.device_id:
                    peer_ip = addr[0]
                    self.peers[peer_ip] = time.time()
                    print(f"[DISCOVERY] Peer encontrado: {peer_ip} ({msg.get('device_id')})")
                    
                    # Responder para o peer saber de nós também
                    self._send_discovery_response(peer_ip)
                    
            except socket.timeout:
                continue
            except Exception as e:
                print(f"[DISCOVERY] Erro: {e}")
        
        sock.close()
    
    def _send_discovery_response(self, peer_ip):
        """Responde para peer descobrir este dispositivo."""
        import socket
        
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            msg = json.dumps({
                'type': 'discovery_response',
                'device_id': self.device_id,
                'timestamp': time.time()
            })
            sock.sendto(msg.encode(), (peer_ip, 5007))
            sock.close()
        except:
            pass
    
    def broadcast_discovery(self):
        """Broadcast para descobrir dispositivos."""
        import socket
        
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
            
            msg = json.dumps({
                'type': 'discovery',
                'device_id': self.device_id,
                'timestamp': time.time()
            })
            
            sock.sendto(msg.encode(), ('224.1.1.1', 5007))
            sock.close()
            print("[DISCOVERY] Broadcast enviado")
        except Exception as e:
            print(f"[DISCOVERY] Erro broadcast: {e}")
    
    def _start_server(self):
        """Inicia servidor HTTP para receber sincronizações."""
        try:
            from flask import Flask, request, jsonify
        except ImportError:
            print("[SERVER] Flask não disponível - servidor desabilitado")
            return
        
        app = Flask(__name__)
        
        @app.route('/sync/push', methods=['POST'])
        def receive_sync():
            """Recebe dados de sincronização de outro dispositivo."""
            try:
                data = request.json
                return self._process_sync_data(data)
            except Exception as e:
                return jsonify({'error': str(e)}), 500
        
        @app.route('/sync/status', methods=['GET'])
        def sync_status():
            """Retorna status para verificação."""
            return jsonify({
                'device_id': self.device_id,
                'timestamp': time.time()
            })
        
        # Rodar em thread separada
        import logging
        log = logging.getLogger('werkzeug')
        log.setLevel(logging.ERROR)
        
        app.run(host='0.0.0.0', port=5008, threaded=True, debug=False)
    
    def _process_sync_data(self, data):
        """Processa dados recebidos de outro dispositivo."""
        try:
            from flask import jsonify
        except ImportError:
            print("[SERVER] Flask não disponível - não pode processar sync")
            return {'success': False, 'error': 'Flask não disponível'}
        
        try:
            materiais = data.get('materiais', [])
            movimentacoes = data.get('movimentacoes', [])
            
            conn = self.db.get_connection()
            cursor = conn.cursor()
            
            records_synced = 0
            
            # Processar materiais
            for mat in materiais:
                cursor.execute('''
                    SELECT sync_version, sync_timestamp FROM materiais WHERE id = ?
                ''', (mat['id'],))
                
                local = cursor.fetchone()
                
                if local:
                    local_version, local_ts = local
                    # Se versão remota é maior ou timestamp mais recente
                    if mat.get('sync_version', 0) > local_version or \
                       mat.get('sync_timestamp', '') > local_ts:
                        cursor.execute('''
                            UPDATE materiais 
                            SET nome=?, descricao=?, quantidade=?, quantidade_minima=?,
                                unidade=?, localizacao=?, categoria=?, sync_version=?,
                                sync_timestamp=?, deleted=?
                            WHERE id=?
                        ''', (mat['nome'], mat['descricao'], mat['quantidade'],
                              mat['quantidade_minima'], mat['unidade'], mat['localizacao'],
                              mat['categoria'], mat['sync_version'], mat['sync_timestamp'],
                              mat.get('deleted', 0), mat['id']))
                        records_synced += 1
                else:
                    # Novo registro
                    cursor.execute('''
                        INSERT INTO materiais (id, codigo, nome, descricao, quantidade,
                                               quantidade_minima, unidade, localizacao,
                                               categoria, sync_version, sync_timestamp, deleted)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (mat['id'], mat['codigo'], mat['nome'], mat['descricao'],
                          mat['quantidade'], mat['quantidade_minima'], mat['unidade'],
                          mat['localizacao'], mat['categoria'], mat['sync_version'],
                          mat['sync_timestamp'], mat.get('deleted', 0)))
                    records_synced += 1
            
            conn.commit()
            conn.close()
            
            # Registrar sync
            self._log_sync(data.get('device_id'), 'received', records_synced, 'success')
            
            return jsonify({
                'success': True,
                'records_synced': records_synced
            })
            
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)})
    
    def _log_sync(self, device_id, sync_type, records, status):
        """Registra operação de sync no log."""
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO sync_log (device_id, sync_type, records_synced, status)
            VALUES (?, ?, ?, ?)
        ''', (device_id, sync_type, records, status))
        conn.commit()
        conn.close()
    
    def sync_to_peer(self, peer_ip, callback=None):
        """Sincroniza dados com um peer específico."""
        if self.is_syncing:
            if callback:
                callback(False, "Sincronização já em andamento")
            return
        
        self.is_syncing = True
        
        try:
            # Obter dados locais
            conn = self.db.get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT id, codigo, nome, descricao, quantidade, quantidade_minima,
                       unidade, localizacao, categoria, sync_version, sync_timestamp, deleted
                FROM materiais
            ''')
            colunas = [desc[0] for desc in cursor.description]
            materiais = [dict(zip(colunas, row)) for row in cursor.fetchall()]
            
            cursor.execute('''
                SELECT * FROM movimentacoes 
                WHERE sync_timestamp > datetime('now', '-7 days')
            ''')
            colunas = [desc[0] for desc in cursor.description]
            movimentacoes = [dict(zip(colunas, row)) for row in cursor.fetchall()]
            
            conn.close()
            
            # Enviar para peer
            data = {
                'device_id': self.device_id,
                'timestamp': time.time(),
                'materiais': materiais,
                'movimentacoes': movimentacoes
            }
            
            # Fazer request HTTP
            try:
                import requests
            except ImportError:
                raise Exception("Requests não disponível no Android")
                
            response = requests.post(
                f'http://{peer_ip}:5008/sync/push',
                json=data,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                records_synced = result.get('records_synced', 0)
                self._log_sync(peer_ip, 'sent', records_synced, 'success')
                
                if callback:
                    callback(True, f"{records_synced} registros sincronizados")
            else:
                raise Exception(f"HTTP {response.status_code}")
                
        except Exception as e:
            print(f"[SYNC] Erro: {e}")
            if callback:
                callback(False, str(e))
        finally:
            self.is_syncing = False
    
    def sync_all(self, callback=None):
        """Sincroniza com todos os peers conhecidos."""
        peers = list(self.peers.keys())
        
        if not peers:
            if callback:
                callback(False, "Nenhum dispositivo encontrado na rede")
            return
        
        results = []
        for peer_ip in peers:
            self.sync_to_peer(peer_ip, lambda success, msg: results.append((peer_ip, success, msg)))
        
        if callback:
            success_count = sum(1 for _, s, _ in results if s)
            callback(True, f"Sincronizado com {success_count}/{len(peers)} dispositivos")


# ============== TELAS KIVY ==============
# As telas (LoginScreen, DashboardScreen, MateriaisScreen, etc)
# sao importadas da pasta screens/ no topo do arquivo
# Usando: from screens.login_screen import LoginScreen
#         from screens.dashboard_screen import DashboardScreen
#         from screens.materiais_screen import MateriaisScreen


# Verificar se telas foram importadas corretamente
try:
    LoginScreen
    DashboardScreen
    MateriaisScreen
    print("[INIT] Telas importadas com sucesso da pasta screens/")
except NameError:
    print("[ERRO] Telas nao importadas - criando telas de emergencia")
    # Telas dummy de emergencia
    class LoginScreen(Screen):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            layout = BoxLayout(orientation='vertical')
            layout.add_widget(Label(text='ERRO: Telas nao carregadas', color=(1,0,0,1)))
            self.add_widget(layout)
    
    class DashboardScreen(Screen):
        def __init__(self, db, sync, **kwargs):
            super().__init__(**kwargs)
            layout = BoxLayout(orientation='vertical')
            layout.add_widget(Label(text='ERRO: Dashboard nao carregado', color=(1,0,0,1)))
            self.add_widget(layout)
    
    class MateriaisScreen(Screen):
        def __init__(self, db, **kwargs):
            super().__init__(**kwargs)
            layout = BoxLayout(orientation='vertical')
            layout.add_widget(Label(text='ERRO: Materiais nao carregado', color=(1,0,0,1)))
            self.add_widget(layout)

# ============== CLASSE PRINCIPAL ==============


class CaixaMestreApp(App):
    """Aplicativo principal."""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.db = DatabaseManager()
        self.sync = SyncManager(self.db)
    
    def build(self):
        # Configurar janela
        Window.bind(on_keyboard=self._on_keyboard)
        
        # Criar screen manager
        sm = ScreenManager(transition=SlideTransition())
        
        # Telas
        sm.add_widget(LoginScreen(name='login'))
        sm.add_widget(DashboardScreen(self.db, self.sync, name='dashboard'))
        sm.add_widget(MateriaisScreen(self.db, name='materiais'))
        # TODO: Adicionar mais telas (movimentacao, buscar, etc.)
        
        # Iniciar sync
        self.sync.start()
        Clock.schedule_interval(lambda dt: self.sync.broadcast_discovery(), 30)  # Broadcast a cada 30s
        
        return sm
    
    def _on_keyboard(self, window, key, scancode, codepoint, modifier):
        """Captura tecla voltar no Android."""
        if key == 27:  # ESC / Botão voltar Android
            # Verificar se pode voltar
            screen = self.root.current_screen
            if self.root.current != 'dashboard':
                self.root.current = 'dashboard'
                return True
        return False
    
    def on_stop(self):
        """Chamado ao fechar app."""
        self.sync.stop()


# ============== ENTRY POINT ==============

if __name__ == '__main__':
    # Verificar dependências opcionais (para desenvolvimento)
    try:
        import flask
        print("[INIT] Flask disponível")
    except ImportError:
        print("[INIT] Flask não disponível - sync server desabilitado")
    
    try:
        import requests
        print("[INIT] Requests disponível")
    except ImportError:
        print("[INIT] Requests não disponível - sync externo desabilitado")
    
    # Iniciar app
    print("[INIT] Iniciando Caixa Mestre Mobile...")
    CaixaMestreApp().run()
