"""
Tela Dashboard - Caixa Mestre Mobile
"""

from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.clock import Clock, mainthread
from kivy.graphics import Color, Rectangle


class DashboardScreen(Screen):
    """Tela principal com dashboard e ações rápidas."""
    
    def __init__(self, db_manager, sync_manager, **kwargs):
        super().__init__(**kwargs)
        self.db = db_manager
        self.sync = sync_manager
        self.build_ui()
        Clock.schedule_interval(self.update_stats, 5)
    
    def build_ui(self):
        layout = BoxLayout(orientation='vertical')
        
        # Header
        header = BoxLayout(size_hint_y=None, height=70, padding=10)
        with header.canvas.before:
            Color(0.1, 0.15, 0.22, 1)
            self.rect_header = Rectangle(pos=header.pos, size=header.size)
        header.bind(pos=self._update_header_rect, size=self._update_header_rect)
        
        header.add_widget(Label(
            text='📦 CAIXA MESTRE',
            font_size='20sp',
            bold=True,
            color=(1, 1, 1, 1),
            size_hint_x=0.6
        ))
        
        self.btn_sync = Button(
            text='🔄',
            font_size='24sp',
            size_hint_x=0.2,
            background_color=(0.2, 0.6, 0.8, 1),
            background_normal=''
        )
        self.btn_sync.bind(on_press=self.do_sync)
        header.add_widget(self.btn_sync)
        
        btn_menu = Button(
            text='☰',
            font_size='24sp',
            size_hint_x=0.2,
            background_color=(0.3, 0.3, 0.3, 1),
            background_normal=''
        )
        btn_menu.bind(on_press=self.show_menu)
        header.add_widget(btn_menu)
        
        layout.add_widget(header)
        
        # Cards de estatísticas
        cards_layout = GridLayout(cols=2, padding=15, spacing=15, size_hint_y=None, height=200)
        
        self.card_total = self.create_card('📦 Total Itens', '0', (0.16, 0.53, 0.72, 1))
        cards_layout.add_widget(self.card_total)
        
        self.card_baixo = self.create_card('⚠️ Estoque Baixo', '0', (0.9, 0.5, 0.2, 1))
        cards_layout.add_widget(self.card_baixo)
        
        self.card_qtd = self.create_card('📊 Qtd Total', '0', (0.2, 0.7, 0.4, 1))
        cards_layout.add_widget(self.card_qtd)
        
        self.card_sync = self.create_card('🌐 Sync', 'Offline', (0.5, 0.5, 0.5, 1))
        cards_layout.add_widget(self.card_sync)
        
        layout.add_widget(cards_layout)
        
        # Título ações
        layout.add_widget(Label(
            text='AÇÕES RÁPIDAS',
            font_size='14sp',
            color=(0.6, 0.7, 0.8, 1),
            size_hint_y=None,
            height=40,
            bold=True
        ))
        
        # Botões de ação
        acoes_layout = GridLayout(cols=2, padding=15, spacing=15, size_hint_y=None, height=220)
        
        acoes = [
            ('📦\nMateriais', 'materiais', (0.16, 0.53, 0.72, 1)),
            ('➕\nEntrada', 'entrada', (0.2, 0.7, 0.4, 1)),
            ('➖\nSaída', 'saida', (0.9, 0.5, 0.2, 1)),
            ('🔍\nBuscar', 'busca', (0.6, 0.6, 0.6, 1)),
        ]
        
        for text, action, color in acoes:
            btn = Button(
                text=text,
                font_size='16sp',
                background_color=color,
                background_normal='',
                halign='center',
                valign='middle'
            )
            btn.bind(on_press=lambda x, a=action: self.do_action(a))
            acoes_layout.add_widget(btn)
        
        layout.add_widget(acoes_layout)
        
        # Alertas
        layout.add_widget(Label(
            text='ALERTAS',
            font_size='14sp',
            color=(0.8, 0.3, 0.3, 1),
            size_hint_y=None,
            height=35,
            bold=True
        ))
        
        self.lbl_alertas = Label(
            text='Sem alertas',
            font_size='13sp',
            color=(0.5, 0.7, 0.5, 1),
            size_hint_y=None,
            height=80
        )
        layout.add_widget(self.lbl_alertas)
        
        # Rodapé
        layout.add_widget(Label(size_hint_y=0.1))
        
        self.add_widget(layout)
    
    def create_card(self, title, value, color):
        """Cria card de estatística."""
        card = BoxLayout(orientation='vertical', padding=12)
        with card.canvas.before:
            Color(*color)
            rect = Rectangle(pos=card.pos, size=card.size)
        card.bind(pos=lambda obj, val, r=rect: self._update_rect(obj, r),
                 size=lambda obj, val, r=rect: self._update_rect(obj, r))
        
        lbl_title = Label(
            text=title,
            font_size='12sp',
            color=(1, 1, 1, 0.8),
            size_hint_y=0.35
        )
        card.add_widget(lbl_title)
        
        lbl_value = Label(
            text=value,
            font_size='24sp',
            bold=True,
            color=(1, 1, 1, 1),
            size_hint_y=0.65
        )
        card.lbl_value = lbl_value
        card.add_widget(lbl_value)
        
        return card
    
    def _update_rect(self, instance, rect):
        """Atualiza retângulo."""
        rect.pos = instance.pos
        rect.size = instance.size
    
    def _update_header_rect(self, instance, value):
        """Atualiza header."""
        self.rect_header.pos = instance.pos
        self.rect_header.size = instance.size
    
    def update_stats(self, dt):
        """Atualiza estatísticas."""
        try:
            stats = self.db.get_stats()
            
            self.card_total.lbl_value.text = str(stats['total_materiais'])
            self.card_baixo.lbl_value.text = str(stats['estoque_baixo'])
            self.card_qtd.lbl_value.text = str(stats['total_itens'])
            
            # Sync status
            peers = len(self.sync.peers)
            if peers > 0:
                self.card_sync.lbl_value.text = f'{peers} device(s)'
                self.card_sync.lbl_value.color = (0.2, 0.9, 0.4, 1)
            else:
                self.card_sync.lbl_value.text = 'Offline'
                self.card_sync.lbl_value.color = (0.8, 0.8, 0.8, 1)
            
            # Alertas
            if stats['estoque_baixo'] > 0:
                self.lbl_alertas.text = f'⚠️ {stats["estoque_baixo"]} item(s) com estoque baixo!'
                self.lbl_alertas.color = (0.9, 0.4, 0.2, 1)
            elif stats['total_materiais'] == 0:
                self.lbl_alertas.text = 'ℹ️ Nenhum material cadastrado'
                self.lbl_alertas.color = (0.7, 0.7, 0.7, 1)
            else:
                self.lbl_alertas.text = '✓ Estoque OK'
                self.lbl_alertas.color = (0.2, 0.8, 0.4, 1)
                
        except Exception as e:
            print(f"[DASHBOARD] Erro stats: {e}")
    
    def do_sync(self, instance):
        """Inicia sincronização."""
        self.btn_sync.text = '⏳'
        self.sync.broadcast_discovery()
        Clock.schedule_once(lambda dt: self._do_sync_delayed(), 2)
    
    def _do_sync_delayed(self):
        """Executa sync."""
        def on_complete(success, msg):
            Clock.schedule_once(lambda dt: self._update_sync_btn(success, msg), 0)
        self.sync.sync_all(on_complete)
    
    @mainthread
    def _update_sync_btn(self, success, msg):
        """Atualiza botão sync."""
        self.btn_sync.text = '🔄' if success else '❌'
        print(f"[SYNC] {msg}")
    
    def show_menu(self, instance):
        """Mostra menu."""
        # TODO: Implementar menu lateral
        pass
    
    def do_action(self, action):
        """Executa ação."""
        if action == 'materiais':
            self.manager.current = 'materiais'
        elif action == 'entrada':
            mov_screen = self.manager.get_screen('movimentacao')
            mov_screen.set_tipo('entrada')
            self.manager.current = 'movimentacao'
        elif action == 'saida':
            mov_screen = self.manager.get_screen('movimentacao')
            mov_screen.set_tipo('saida')
            self.manager.current = 'movimentacao'
        elif action == 'busca':
            self.manager.current = 'busca'
    
    def on_enter(self):
        """Chamado ao entrar."""
        self.update_stats(0)
