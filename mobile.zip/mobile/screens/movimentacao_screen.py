"""
Tela de Movimentação (Entrada/Saída) - Caixa Mestre Mobile
"""

from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.clock import Clock
from kivy.properties import StringProperty
from kivy.graphics import Color, Rectangle


class MovimentacaoScreen(Screen):
    """Tela para registrar entrada ou saída de materiais."""
    
    tipo_mov = StringProperty('entrada')  # 'entrada' ou 'saida'
    material_selecionado = None
    
    def __init__(self, db_manager, **kwargs):
        super().__init__(**kwargs)
        self.db = db_manager
        self.build_ui()
    
    def build_ui(self):
        self.layout = BoxLayout(orientation='vertical')
        
        # Header dinâmico
        self.header = BoxLayout(size_hint_y=None, height=60, padding=10)
        self.lbl_titulo = Label(
            text='➕ ENTRADA',
            font_size='20sp',
            bold=True,
            color=(1, 1, 1, 1)
        )
        self.header.add_widget(self.lbl_titulo)
        self.layout.add_widget(self.header)
        
        # Material selecionado
        self.card_material = BoxLayout(
            orientation='vertical',
            size_hint_y=None,
            height=120,
            padding=15,
            spacing=5
        )
        with self.card_material.canvas.before:
            Color(0.2, 0.35, 0.45, 1)
            self.rect_material = Rectangle(pos=self.card_material.pos, size=self.card_material.size)
        self.card_material.bind(pos=self._update_rect, size=self._update_rect)
        
        self.lbl_material_nome = Label(
            text='Toque para selecionar material',
            font_size='18sp',
            color=(0.8, 0.8, 0.8, 1),
            size_hint_y=0.6
        )
        self.card_material.add_widget(self.lbl_material_nome)
        
        self.lbl_material_estoque = Label(
            text='',
            font_size='14sp',
            color=(0.6, 0.8, 1, 1),
            size_hint_y=0.4
        )
        self.card_material.add_widget(self.lbl_material_estoque)
        
        self.card_material.bind(on_touch_down=self.on_material_card_click)
        self.layout.add_widget(self.card_material)
        
        # Campos
        form_layout = GridLayout(cols=1, padding=20, spacing=15)
        
        # Quantidade
        form_layout.add_widget(Label(
            text='Quantidade:',
            color=(1, 1, 1, 1),
            size_hint_y=None,
            height=30,
            halign='left'
        ))
        
        self.input_quantidade = TextInput(
            multiline=False,
            input_type='number',
            font_size='24sp',
            size_hint_y=None,
            height=60,
            halign='center'
        )
        form_layout.add_widget(self.input_quantidade)
        
        # Responsável
        form_layout.add_widget(Label(
            text='Responsável:',
            color=(1, 1, 1, 1),
            size_hint_y=None,
            height=30,
            halign='left'
        ))
        
        self.input_responsavel = TextInput(
            multiline=False,
            font_size='18sp',
            size_hint_y=None,
            height=50,
            hint_text='Nome do responsável'
        )
        form_layout.add_widget(self.input_responsavel)
        
        # Observação
        form_layout.add_widget(Label(
            text='Observação (opcional):',
            color=(1, 1, 1, 1),
            size_hint_y=None,
            height=30,
            halign='left'
        ))
        
        self.input_observacao = TextInput(
            multiline=True,
            font_size='16sp',
            size_hint_y=None,
            height=100,
            hint_text='Detalhes adicionais...'
        )
        form_layout.add_widget(self.input_observacao)
        
        self.layout.add_widget(form_layout)
        
        # Botões de ação
        btn_layout = BoxLayout(size_hint_y=None, height=120, padding=20, spacing=10)
        
        btn_cancelar = Button(
            text='CANCELAR',
            font_size='16sp',
            background_color=(0.5, 0.5, 0.5, 1)
        )
        btn_cancelar.bind(on_press=self.voltar)
        btn_layout.add_widget(btn_cancelar)
        
        self.btn_confirmar = Button(
            text='CONFIRMAR',
            font_size='18sp',
            bold=True,
            background_color=(0.16, 0.53, 0.72, 1)
        )
        self.btn_confirmar.bind(on_press=self.confirmar)
        btn_layout.add_widget(self.btn_confirmar)
        
        self.layout.add_widget(btn_layout)
        
        # Status
        self.lbl_status = Label(
            text='',
            color=(0.9, 0.9, 0.9, 1),
            size_hint_y=None,
            height=40
        )
        self.layout.add_widget(self.lbl_status)
        
        self.add_widget(self.layout)
    
    def _update_rect(self, instance, value):
        """Atualiza retângulo de fundo."""
        if hasattr(self, 'rect_material'):
            self.rect_material.pos = instance.pos
            self.rect_material.size = instance.size
    
    def set_tipo(self, tipo):
        """Define o tipo de movimentação."""
        self.tipo_mov = tipo
        
        if tipo == 'entrada':
            self.lbl_titulo.text = '➕ ENTRADA'
            self.lbl_titulo.color = (0.2, 0.8, 0.4, 1)
            self.btn_confirmar.background_color = (0.2, 0.7, 0.4, 1)
        else:
            self.lbl_titulo.text = '➖ SAÍDA'
            self.lbl_titulo.color = (0.9, 0.5, 0.2, 1)
            self.btn_confirmar.background_color = (0.9, 0.4, 0.2, 1)
    
    def on_material_card_click(self, instance, touch):
        """Abre popup para selecionar material."""
        if instance.collide_point(*touch.pos):
            self.show_selecionar_material()
    
    def show_selecionar_material(self):
        """Mostra lista de materiais para seleção."""
        materiais = self.db.get_materiais()
        
        content = BoxLayout(orientation='vertical', padding=10, spacing=10)
        
        # Busca
        search_box = BoxLayout(size_hint_y=None, height=50)
        search_input = TextInput(
            hint_text='Buscar...',
            multiline=False,
            size_hint_x=0.8
        )
        btn_buscar = Button(
            text='🔍',
            size_hint_x=0.2,
            background_color=(0.16, 0.53, 0.72, 1)
        )
        search_box.add_widget(search_input)
        search_box.add_widget(btn_buscar)
        content.add_widget(search_box)
        
        # Lista
        scroll = ScrollView()
        list_layout = BoxLayout(orientation='vertical', size_hint_y=None)
        list_layout.bind(minimum_height=list_layout.setter('height'))
        
        for mat in materiais:
            btn = Button(
                text=f"{mat['nome']}\nEstoque: {mat['quantidade']} {mat['unidade']}",
                size_hint_y=None,
                height=70,
                halign='left',
                background_color=(0.2, 0.3, 0.4, 1)
            )
            btn.bind(on_press=lambda x, m=mat: self.selecionar_material(m))
            list_layout.add_widget(btn)
        
        scroll.add_widget(list_layout)
        content.add_widget(scroll)
        
        # Botão cancelar
        btn_cancelar = Button(
            text='CANCELAR',
            size_hint_y=None,
            height=50,
            background_color=(0.5, 0.5, 0.5, 1)
        )
        content.add_widget(btn_cancelar)
        
        self.popup_material = Popup(
            title='Selecionar Material',
            content=content,
            size_hint=(0.9, 0.8)
        )
        
        btn_cancelar.bind(on_press=self.popup_material.dismiss)
        self.popup_material.open()
    
    def selecionar_material(self, material):
        """Seleciona material."""
        self.material_selecionado = material
        self.lbl_material_nome.text = material['nome']
        self.lbl_material_nome.color = (1, 1, 1, 1)
        self.lbl_material_estoque.text = f"Estoque atual: {material['quantidade']} {material['unidade']}"
        
        if self.popup_material:
            self.popup_material.dismiss()
    
    def confirmar(self, instance):
        """Confirma movimentação."""
        if not self.material_selecionado:
            self.lbl_status.text = '❌ Selecione um material'
            self.lbl_status.color = (0.9, 0.3, 0.3, 1)
            return
        
        try:
            quantidade = float(self.input_quantidade.text)
            if quantidade <= 0:
                raise ValueError()
        except:
            self.lbl_status.text = '❌ Quantidade inválida'
            self.lbl_status.color = (0.9, 0.3, 0.3, 1)
            return
        
        responsavel = self.input_responsavel.text.strip()
        if not responsavel:
            responsavel = 'Sistema Mobile'
        
        # Calcular nova quantidade
        mat = self.material_selecionado
        if self.tipo_mov == 'entrada':
            nova_qtd = mat['quantidade'] + quantidade
        else:
            nova_qtd = mat['quantidade'] - quantidade
            if nova_qtd < 0:
                self.lbl_status.text = '❌ Estoque insuficiente'
                self.lbl_status.color = (0.9, 0.3, 0.3, 1)
                return
        
        # Registrar
        try:
            self.db.update_quantidade(
                mat['id'],
                nova_qtd,
                self.tipo_mov,
                responsavel
            )
            
            self.lbl_status.text = f'✓ {self.tipo_mov.upper()} registrada!'
            self.lbl_status.color = (0.2, 0.8, 0.4, 1)
            
            # Limpar campos
            Clock.schedule_once(lambda dt: self.limpar_campos(), 1.5)
            
        except Exception as e:
            self.lbl_status.text = f'❌ Erro: {str(e)}'
            self.lbl_status.color = (0.9, 0.3, 0.3, 1)
    
    def limpar_campos(self):
        """Limpa campos após sucesso."""
        self.material_selecionado = None
        self.lbl_material_nome.text = 'Toque para selecionar material'
        self.lbl_material_nome.color = (0.8, 0.8, 0.8, 1)
        self.lbl_material_estoque.text = ''
        self.input_quantidade.text = ''
        self.input_responsavel.text = ''
        self.input_observacao.text = ''
        self.lbl_status.text = ''
        
        # Voltar para dashboard
        self.manager.current = 'dashboard'
    
    def voltar(self, instance=None):
        """Volta para dashboard."""
        self.limpar_campos()
        self.manager.current = 'dashboard'
    
    def on_enter(self):
        """Chamado ao entrar na tela."""
        self.lbl_status.text = ''
