"""
Tela de Login - Caixa Mestre Mobile
"""

from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.graphics import Color, Rectangle


class LoginScreen(Screen):
    """Tela de login simplificada."""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.build_ui()
    
    def build_ui(self):
        # Fundo com cor
        with self.canvas.before:
            Color(0.12, 0.19, 0.26, 1)
            self.rect = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self._update_rect, size=self._update_rect)
        
        layout = BoxLayout(orientation='vertical', padding=30, spacing=15)
        
        # Espaço superior
        layout.add_widget(Label(size_hint_y=0.2))
        
        # Logo/Ícone
        layout.add_widget(Label(
            text='📦',
            font_size='80sp',
            size_hint_y=None,
            height=100
        ))
        
        # Título
        layout.add_widget(Label(
            text='CAIXA MESTRE',
            font_size='28sp',
            bold=True,
            color=(1, 1, 1, 1),
            size_hint_y=None,
            height=50
        ))
        
        layout.add_widget(Label(
            text='Gestão de Estoque',
            font_size='16sp',
            color=(0.7, 0.8, 0.9, 1),
            size_hint_y=None,
            height=30
        ))
        
        # Espaço
        layout.add_widget(Label(size_hint_y=0.1))
        
        # PIN
        layout.add_widget(Label(
            text='Digite seu PIN:',
            font_size='16sp',
            color=(1, 1, 1, 1),
            size_hint_y=None,
            height=30
        ))
        
        self.pin_input = TextInput(
            multiline=False,
            password=True,
            input_type='number',
            font_size='28sp',
            size_hint_y=None,
            height=70,
            halign='center',
            background_color=(0.2, 0.3, 0.4, 1),
            foreground_color=(1, 1, 1, 1),
            cursor_color=(1, 1, 1, 1)
        )
        layout.add_widget(self.pin_input)
        
        # Mensagem de erro
        self.lbl_erro = Label(
            text='',
            font_size='14sp',
            color=(0.9, 0.3, 0.3, 1),
            size_hint_y=None,
            height=30
        )
        layout.add_widget(self.lbl_erro)
        
        # Botão entrar
        btn_entrar = Button(
            text='ENTRAR',
            font_size='18sp',
            size_hint_y=None,
            height=60,
            background_color=(0.16, 0.53, 0.72, 1),
            background_normal=''
        )
        btn_entrar.bind(on_press=self.do_login)
        layout.add_widget(btn_entrar)
        
        # Botão offline
        btn_offline = Button(
            text='MODO OFFLINE',
            font_size='14sp',
            size_hint_y=None,
            height=50,
            background_color=(0.4, 0.4, 0.4, 0.5),
            background_normal=''
        )
        btn_offline.bind(on_press=self.go_offline)
        layout.add_widget(btn_offline)
        
        # Info
        layout.add_widget(Label(
            text='PIN padrão: 1234',
            font_size='12sp',
            color=(0.5, 0.5, 0.5, 1),
            size_hint_y=None,
            height=30
        ))
        
        # Espaço inferior
        layout.add_widget(Label(size_hint_y=0.3))
        
        self.add_widget(layout)
    
    def _update_rect(self, instance, value):
        """Atualiza retângulo de fundo."""
        self.rect.pos = instance.pos
        self.rect.size = instance.size
    
    def do_login(self, instance=None):
        """Realiza login."""
        pin = self.pin_input.text.strip()
        
        if pin == '1234':
            self.lbl_erro.text = ''
            self.pin_input.text = ''
            self.manager.current = 'dashboard'
        else:
            self.lbl_erro.text = 'PIN incorreto'
            self.pin_input.text = ''
    
    def go_offline(self, instance):
        """Entra em modo offline."""
        self.lbl_erro.text = ''
        self.pin_input.text = ''
        self.manager.current = 'dashboard'
    
    def on_enter(self):
        """Chamado ao entrar na tela."""
        self.lbl_erro.text = ''
        self.pin_input.text = ''
        self.pin_input.focus = True
