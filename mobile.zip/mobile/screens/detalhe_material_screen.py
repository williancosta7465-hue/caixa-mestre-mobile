"""
Tela de Detalhes do Material - Caixa Mestre Mobile
"""

from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.graphics import Color, Rectangle


class DetalheMaterialScreen(Screen):
    """Tela de detalhes de um material específico."""
    
    def __init__(self, db_manager, **kwargs):
        super().__init__(**kwargs)
        self.db = db_manager
        self.material = None
        self.build_ui()
    
    def build_ui(self):
        self.layout = BoxLayout(orientation='vertical')
        
        # Header
        header = BoxLayout(size_hint_y=None, height=60, padding=10)
        header.add_widget(Label(
            text='📦 DETALHES',
            font_size='18sp',
            bold=True,
            color=(1, 1, 1, 1)
        ))
        layout.add_widget(header)
        
        # Conteúdo scrollável
        scroll = ScrollView()
        self.content = BoxLayout(orientation='vertical', size_hint_y=None, padding=20, spacing=15)
        self.content.bind(minimum_height=self.content.setter('height'))
        
        # Nome do material
        self.lbl_nome = Label(
            text='',
            font_size='22sp',
            bold=True,
            color=(1, 1, 1, 1),
            size_hint_y=None,
            height=60
        )
        self.content.add_widget(self.lbl_nome)
        
        # Status (OK/Baixo/Crítico)
        self.lbl_status = Label(
            text='',
            font_size='14sp',
            size_hint_y=None,
            height=30
        )
        self.content.add_widget(self.lbl_status)
        
        # Informações em grid
        info_grid = GridLayout(cols=2, spacing=10, size_hint_y=None, height=250)
        
        labels = [
            ('Código:', 'lbl_codigo'),
            ('Quantidade:', 'lbl_quantidade'),
            ('Mínimo:', 'lbl_minimo'),
            ('Unidade:', 'lbl_unidade'),
            ('Localização:', 'lbl_localizacao'),
            ('Categoria:', 'lbl_categoria'),
        ]
        
        for label_text, attr_name in labels:
            info_grid.add_widget(Label(
                text=label_text,
                color=(0.7, 0.7, 0.7, 1),
                halign='right',
                size_hint_x=0.4
            ))
            lbl = Label(
                text='',
                color=(1, 1, 1, 1),
                halign='left',
                size_hint_x=0.6
            )
            setattr(self, attr_name, lbl)
            info_grid.add_widget(lbl)
        
        self.content.add_widget(info_grid)
        
        # Descrição
        self.content.add_widget(Label(
            text='Descrição:',
            color=(0.7, 0.7, 0.7, 1),
            size_hint_y=None,
            height=30,
            halign='left'
        ))
        
        self.lbl_descricao = Label(
            text='',
            color=(0.9, 0.9, 0.9, 1),
            size_hint_y=None,
            height=80,
            halign='left',
            valign='top'
        )
        self.content.add_widget(self.lbl_descricao)
        
        # Histórico de movimentações
        self.content.add_widget(Label(
            text='Últimas Movimentações:',
            font_size='16sp',
            bold=True,
            color=(1, 1, 1, 1),
            size_hint_y=None,
            height=40
        ))
        
        self.movimentacoes_layout = BoxLayout(orientation='vertical', size_hint_y=None)
        self.movimentacoes_layout.bind(minimum_height=self.movimentacoes_layout.setter('height'))
        self.content.add_widget(self.movimentacoes_layout)
        
        scroll.add_widget(self.content)
        self.layout.add_widget(scroll)
        
        # Botões de ação
        btn_layout = BoxLayout(size_hint_y=None, height=70, padding=10, spacing=10)
        
        btn_voltar = Button(
            text='← VOLTAR',
            font_size='16sp',
            background_color=(0.5, 0.5, 0.5, 1)
        )
        btn_voltar.bind(on_press=self.voltar)
        btn_layout.add_widget(btn_voltar)
        
        btn_entrada = Button(
            text='➕ ENTRADA',
            font_size='16sp',
            background_color=(0.2, 0.7, 0.4, 1)
        )
        btn_entrada.bind(on_press=self.ir_entrada)
        btn_layout.add_widget(btn_entrada)
        
        btn_saida = Button(
            text='➖ SAÍDA',
            font_size='16sp',
            background_color=(0.9, 0.4, 0.2, 1)
        )
        btn_saida.bind(on_press=self.ir_saida)
        btn_layout.add_widget(btn_saida)
        
        self.layout.add_widget(btn_layout)
        
        self.add_widget(self.layout)
    
    def set_material(self, material):
        """Define o material a ser exibido."""
        self.material = material
        self.atualizar_dados()
    
    def atualizar_dados(self):
        """Atualiza dados na tela."""
        if not self.material:
            return
        
        m = self.material
        
        # Nome
        self.lbl_nome.text = m['nome']
        
        # Status
        if m['quantidade'] == 0:
            self.lbl_status.text = '⚠️ ESTOQUE CRÍTICO'
            self.lbl_status.color = (0.9, 0.3, 0.3, 1)
        elif m['quantidade'] <= m.get('quantidade_minima', 0):
            self.lbl_status.text = '⚠️ ESTOQUE BAIXO'
            self.lbl_status.color = (0.9, 0.5, 0.2, 1)
        else:
            self.lbl_status.text = '✓ ESTOQUE OK'
            self.lbl_status.color = (0.2, 0.8, 0.4, 1)
        
        # Informações
        self.lbl_codigo.text = m.get('codigo') or 'N/A'
        self.lbl_quantidade.text = str(m['quantidade'])
        self.lbl_minimo.text = str(m.get('quantidade_minima', 0))
        self.lbl_unidade.text = m.get('unidade', 'UN')
        self.lbl_localizacao.text = m.get('localizacao') or 'N/A'
        self.lbl_categoria.text = m.get('categoria') or 'Geral'
        self.lbl_descricao.text = m.get('descricao') or 'Sem descrição'
        
        # Carregar movimentações
        self.carregar_movimentacoes()
    
    def carregar_movimentacoes(self):
        """Carrega histórico de movimentações."""
        self.movimentacoes_layout.clear_widgets()
        
        try:
            conn = self.db.get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT tipo, quantidade, responsavel, 
                       datetime(sync_timestamp, 'localtime') as data
                FROM movimentacoes 
                WHERE material_id = ?
                ORDER BY sync_timestamp DESC
                LIMIT 5
            ''', (self.material['id'],))
            
            movimentacoes = cursor.fetchall()
            conn.close()
            
            if not movimentacoes:
                self.movimentacoes_layout.add_widget(Label(
                    text='Nenhuma movimentação registrada',
                    color=(0.6, 0.6, 0.6, 1),
                    size_hint_y=None,
                    height=40
                ))
                return
            
            for mov in movimentacoes:
                tipo, qtd, resp, data = mov
                
                # Ícone baseado no tipo
                if tipo == 'entrada':
                    icone = '➕'
                    cor = (0.2, 0.8, 0.4, 1)
                else:
                    icone = '➖'
                    cor = (0.9, 0.5, 0.2, 1)
                
                linha = BoxLayout(size_hint_y=None, height=50)
                linha.add_widget(Label(
                    text=f'{icone} {tipo.upper()}',
                    color=cor,
                    size_hint_x=0.25
                ))
                linha.add_widget(Label(
                    text=f'Qtd: {qtd}',
                    color=(1, 1, 1, 1),
                    size_hint_x=0.25
                ))
                linha.add_widget(Label(
                    text=resp[:15],
                    color=(0.8, 0.8, 0.8, 1),
                    size_hint_x=0.25
                ))
                linha.add_widget(Label(
                    text=data[:10] if data else '',
                    color=(0.6, 0.6, 0.6, 1),
                    size_hint_x=0.25
                ))
                
                self.movimentacoes_layout.add_widget(linha)
                
        except Exception as e:
            print(f"[DETALHE] Erro ao carregar movimentações: {e}")
    
    def voltar(self, instance=None):
        """Volta para tela anterior."""
        self.manager.current = 'busca'
    
    def ir_entrada(self, instance):
        """Vai para tela de entrada."""
        mov_screen = self.manager.get_screen('movimentacao')
        mov_screen.set_tipo('entrada')
        if self.material:
            mov_screen.material_selecionado = self.material
            mov_screen.lbl_material_nome.text = self.material['nome']
            mov_screen.lbl_material_nome.color = (1, 1, 1, 1)
            mov_screen.lbl_material_estoque.text = f"Estoque: {self.material['quantidade']}"
        self.manager.current = 'movimentacao'
    
    def ir_saida(self, instance):
        """Vai para tela de saída."""
        mov_screen = self.manager.get_screen('movimentacao')
        mov_screen.set_tipo('saida')
        if self.material:
            mov_screen.material_selecionado = self.material
            mov_screen.lbl_material_nome.text = self.material['nome']
            mov_screen.lbl_material_nome.color = (1, 1, 1, 1)
            mov_screen.lbl_material_estoque.text = f"Estoque: {self.material['quantidade']}"
        self.manager.current = 'movimentacao'
    
    def on_enter(self):
        """Chamado ao entrar na tela."""
        if self.material:
            self.atualizar_dados()
