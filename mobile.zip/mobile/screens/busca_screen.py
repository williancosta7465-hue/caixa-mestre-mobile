"""
Tela de Busca Avançada - Caixa Mestre Mobile
"""

from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.togglebutton import ToggleButton
from kivy.graphics import Color, Rectangle


class BuscaScreen(Screen):
    """Tela de busca avançada de materiais."""
    
    def __init__(self, db_manager, **kwargs):
        super().__init__(**kwargs)
        self.db = db_manager
        self.build_ui()
    
    def build_ui(self):
        layout = BoxLayout(orientation='vertical')
        
        # Header
        header = BoxLayout(size_hint_y=None, height=60, padding=10)
        header.add_widget(Label(
            text='🔍 BUSCA',
            font_size='20sp',
            bold=True,
            color=(1, 1, 1, 1)
        ))
        layout.add_widget(header)
        
        # Campo de busca
        search_box = BoxLayout(size_hint_y=None, height=60, padding=10, spacing=5)
        
        self.search_input = TextInput(
            hint_text='Digite nome, código ou descrição...',
            multiline=False,
            font_size='16sp',
            size_hint_x=0.75
        )
        search_box.add_widget(self.search_input)
        
        btn_buscar = Button(
            text='BUSCAR',
            font_size='16sp',
            size_hint_x=0.25,
            background_color=(0.16, 0.53, 0.72, 1)
        )
        btn_buscar.bind(on_press=self.realizar_busca)
        search_box.add_widget(btn_buscar)
        
        layout.add_widget(search_box)
        
        # Filtros rápidos
        filtros_box = BoxLayout(size_hint_y=None, height=50, padding=5)
        
        self.btn_todos = ToggleButton(
            text='Todos',
            group='filtro',
            state='down',
            background_color=(0.16, 0.53, 0.72, 1)
        )
        self.btn_todos.bind(on_press=lambda x: self.set_filtro('todos'))
        filtros_box.add_widget(self.btn_todos)
        
        self.btn_baixo = ToggleButton(
            text='Estoque Baixo',
            group='filtro',
            background_color=(0.9, 0.5, 0.2, 1)
        )
        self.btn_baixo.bind(on_press=lambda x: self.set_filtro('baixo'))
        filtros_box.add_widget(self.btn_baixo)
        
        self.btn_critico = ToggleButton(
            text='Crítico',
            group='filtro',
            background_color=(0.9, 0.3, 0.3, 1)
        )
        self.btn_critico.bind(on_press=lambda x: self.set_filtro('critico'))
        filtros_box.add_widget(self.btn_critico)
        
        layout.add_widget(filtros_box)
        
        # Resultados
        self.lbl_resultados = Label(
            text='Realize uma busca',
            color=(0.7, 0.7, 0.7, 1),
            size_hint_y=None,
            height=30
        )
        layout.add_widget(self.lbl_resultados)
        
        # Lista de resultados
        scroll = ScrollView()
        self.results_layout = BoxLayout(orientation='vertical', size_hint_y=None, spacing=5)
        self.results_layout.bind(minimum_height=self.results_layout.setter('height'))
        scroll.add_widget(self.results_layout)
        layout.add_widget(scroll)
        
        # Botão voltar
        btn_voltar = Button(
            text='← VOLTAR',
            size_hint_y=None,
            height=60,
            background_color=(0.3, 0.3, 0.3, 1)
        )
        btn_voltar.bind(on_press=lambda x: setattr(self.manager, 'current', 'dashboard'))
        layout.add_widget(btn_voltar)
        
        self.add_widget(layout)
        
        self.filtro_atual = 'todos'
    
    def set_filtro(self, filtro):
        """Define filtro atual."""
        self.filtro_atual = filtro
        self.realizar_busca(None)
    
    def realizar_busca(self, instance):
        """Executa busca."""
        termo = self.search_input.text.strip()
        
        # Buscar no banco
        materiais = self.db.get_materiais(busca=termo if termo else None)
        
        # Aplicar filtros
        if self.filtro_atual == 'baixo':
            materiais = [m for m in materiais if m['quantidade'] <= m.get('quantidade_minima', 0)]
        elif self.filtro_atual == 'critico':
            materiais = [m for m in materiais if m['quantidade'] == 0]
        
        self.mostrar_resultados(materiais)
    
    def mostrar_resultados(self, materiais):
        """Mostra resultados na lista."""
        self.results_layout.clear_widgets()
        
        if not materiais:
            self.lbl_resultados.text = 'Nenhum resultado encontrado'
            self.lbl_resultados.color = (0.9, 0.5, 0.2, 1)
            return
        
        self.lbl_resultados.text = f'{len(materiais)} resultado(s)'
        self.lbl_resultados.color = (0.2, 0.8, 0.4, 1)
        
        for mat in materiais:
            # Determinar cor baseado no estoque
            if mat['quantidade'] == 0:
                cor = (0.9, 0.3, 0.3, 1)  # Vermelho - crítico
                status = '⚠️ CRÍTICO'
            elif mat['quantidade'] <= mat.get('quantidade_minima', 0):
                cor = (0.9, 0.5, 0.2, 1)  # Laranja - baixo
                status = '⚠️ BAIXO'
            else:
                cor = (0.2, 0.7, 0.4, 1)  # Verde - OK
                status = '✓ OK'
            
            # Card do material
            card = BoxLayout(
                orientation='vertical',
                size_hint_y=None,
                height=100,
                padding=10
            )
            with card.canvas.before:
                Color(0.15, 0.25, 0.35, 1)
                rect = Rectangle(pos=card.pos, size=card.size)
            card.bind(pos=lambda obj, val, r=rect: self._update_rect(obj, r), 
                     size=lambda obj, val, r=rect: self._update_rect(obj, r))
            
            # Linha 1: Nome e status
            row1 = BoxLayout(size_hint_y=0.5)
            row1.add_widget(Label(
                text=mat['nome'],
                font_size='16sp',
                bold=True,
                color=(1, 1, 1, 1),
                halign='left',
                text_size=(None, None)
            ))
            row1.add_widget(Label(
                text=status,
                font_size='12sp',
                color=cor,
                size_hint_x=0.3
            ))
            card.add_widget(row1)
            
            # Linha 2: Código e quantidade
            row2 = BoxLayout(size_hint_y=0.5)
            codigo = mat.get('codigo', '') or 'Sem código'
            row2.add_widget(Label(
                text=f'📦 {codigo}',
                font_size='12sp',
                color=(0.7, 0.7, 0.7, 1),
                halign='left'
            ))
            row2.add_widget(Label(
                text=f"Qtd: {mat['quantidade']} {mat.get('unidade', 'UN')}",
                font_size='14sp',
                color=(0.8, 0.9, 1, 1),
                size_hint_x=0.4,
                halign='right'
            ))
            card.add_widget(row2)
            
            # Click para detalhes
            card.bind(on_touch_down=lambda touch, obj, m=mat: self.on_card_click(obj, touch, m))
            
            self.results_layout.add_widget(card)
    
    def _update_rect(self, instance, rect):
        """Atualiza retângulo."""
        rect.pos = instance.pos
        rect.size = instance.size
    
    def on_card_click(self, instance, touch, material):
        """Abre detalhes do material."""
        if instance.collide_point(*touch.pos):
            # Guardar material e ir para tela de detalhes
            detalhe_screen = self.manager.get_screen('detalhe_material')
            detalhe_screen.set_material(material)
            self.manager.current = 'detalhe_material'
    
    def on_enter(self):
        """Chamado ao entrar na tela."""
        self.search_input.text = ''
        self.results_layout.clear_widgets()
        self.lbl_resultados.text = 'Realize uma busca'
        self.lbl_resultados.color = (0.7, 0.7, 0.7, 1)
        self.search_input.focus = True
