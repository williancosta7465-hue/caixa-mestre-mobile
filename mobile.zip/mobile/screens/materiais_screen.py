"""
Tela de Lista de Materiais - Caixa Mestre Mobile
"""

from kivy.uix.screen import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.graphics import Color, Rectangle


class MateriaisScreen(Screen):
    """Tela de listagem e gerenciamento de materiais."""
    
    def __init__(self, db_manager, **kwargs):
        super().__init__(**kwargs)
        self.db = db_manager
        self.build_ui()
    
    def build_ui(self):
        layout = BoxLayout(orientation='vertical')
        
        # Header
        header = BoxLayout(size_hint_y=None, height=60, padding=10)
        with header.canvas.before:
            Color(0.1, 0.15, 0.22, 1)
            rect = Rectangle(pos=header.pos, size=header.size)
        header.bind(pos=lambda obj, val, r=rect: self._update_rect(obj, r),
                    size=lambda obj, val, r=rect: self._update_rect(obj, r))
        
        header.add_widget(Label(
            text='📦 MATERIAIS',
            font_size='20sp',
            bold=True,
            color=(1, 1, 1, 1)
        ))
        layout.add_widget(header)
        
        # Busca
        search_box = BoxLayout(size_hint_y=None, height=60, padding=10, spacing=5)
        
        self.search_input = TextInput(
            hint_text='Buscar material...',
            multiline=False,
            font_size='16sp',
            size_hint_x=0.75
        )
        search_box.add_widget(self.search_input)
        
        btn_buscar = Button(
            text='🔍',
            font_size='20sp',
            size_hint_x=0.15,
            background_color=(0.16, 0.53, 0.72, 1),
            background_normal=''
        )
        btn_buscar.bind(on_press=lambda x: self.load_materiais(self.search_input.text))
        search_box.add_widget(btn_buscar)
        
        btn_add = Button(
            text='➕',
            font_size='20sp',
            size_hint_x=0.1,
            background_color=(0.2, 0.7, 0.4, 1),
            background_normal=''
        )
        btn_add.bind(on_press=self.show_add_material)
        search_box.add_widget(btn_add)
        
        layout.add_widget(search_box)
        
        # Status
        self.lbl_status = Label(
            text='Carregando...',
            color=(0.7, 0.7, 0.7, 1),
            size_hint_y=None,
            height=30
        )
        layout.add_widget(self.lbl_status)
        
        # Lista
        scroll = ScrollView()
        self.list_layout = BoxLayout(orientation='vertical', size_hint_y=None, spacing=5)
        self.list_layout.bind(minimum_height=self.list_layout.setter('height'))
        scroll.add_widget(self.list_layout)
        layout.add_widget(scroll)
        
        # Botão voltar
        btn_voltar = Button(
            text='← VOLTAR PARA DASHBOARD',
            size_hint_y=None,
            height=60,
            background_color=(0.3, 0.3, 0.3, 1),
            background_normal=''
        )
        btn_voltar.bind(on_press=lambda x: setattr(self.manager, 'current', 'dashboard'))
        layout.add_widget(btn_voltar)
        
        self.add_widget(layout)
    
    def _update_rect(self, instance, rect):
        """Atualiza retângulo."""
        rect.pos = instance.pos
        rect.size = instance.size
    
    def load_materiais(self, busca=None):
        """Carrega lista de materiais."""
        self.list_layout.clear_widgets()
        
        try:
            materiais = self.db.get_materiais(busca=busca if busca else None)
            
            if not materiais:
                self.lbl_status.text = 'Nenhum material encontrado'
                self.lbl_status.color = (0.9, 0.5, 0.2, 1)
                return
            
            self.lbl_status.text = f'{len(materiais)} material(is)'
            self.lbl_status.color = (0.2, 0.8, 0.4, 1)
            
            for mat in materiais:
                # Determinar cor do status
                if mat['quantidade'] == 0:
                    status_color = (0.9, 0.3, 0.3, 1)  # Vermelho
                    status_text = '⚠️'
                elif mat['quantidade'] <= mat.get('quantidade_minima', 0):
                    status_color = (0.9, 0.5, 0.2, 1)  # Laranja
                    status_text = '⚡'
                else:
                    status_color = (0.2, 0.8, 0.4, 1)  # Verde
                    status_text = '✓'
                
                # Card do material
                card = BoxLayout(
                    orientation='vertical',
                    size_hint_y=None,
                    height=90,
                    padding=12
                )
                with card.canvas.before:
                    Color(0.15, 0.25, 0.35, 1)
                    rect = Rectangle(pos=card.pos, size=card.size)
                card.bind(pos=lambda obj, val, r=rect: self._update_card_rect(obj, r),
                         size=lambda obj, val, r=rect: self._update_card_rect(obj, r))
                
                # Linha 1: Status e nome
                row1 = BoxLayout(size_hint_y=0.55)
                lbl_status = Label(
                    text=status_text,
                    font_size='16sp',
                    color=status_color,
                    size_hint_x=0.15
                )
                row1.add_widget(lbl_status)
                
                lbl_nome = Label(
                    text=mat['nome'],
                    font_size='16sp',
                    bold=True,
                    color=(1, 1, 1, 1),
                    size_hint_x=0.85,
                    halign='left',
                    text_size=(None, None)
                )
                row1.add_widget(lbl_nome)
                card.add_widget(row1)
                
                # Linha 2: Código e quantidade
                row2 = BoxLayout(size_hint_y=0.45)
                codigo = mat.get('codigo') or 'Sem código'
                lbl_codigo = Label(
                    text=f'📦 {codigo}',
                    font_size='12sp',
                    color=(0.7, 0.7, 0.7, 1),
                    size_hint_x=0.6,
                    halign='left'
                )
                row2.add_widget(lbl_codigo)
                
                lbl_qtd = Label(
                    text=f"{mat['quantidade']} {mat.get('unidade', 'UN')}",
                    font_size='14sp',
                    color=(0.8, 0.9, 1, 1),
                    size_hint_x=0.4,
                    halign='right'
                )
                row2.add_widget(lbl_qtd)
                card.add_widget(row2)
                
                # Click
                card.bind(on_touch_down=lambda touch, obj, m=mat: self.on_card_click(obj, touch, m))
                
                self.list_layout.add_widget(card)
                
        except Exception as e:
            self.lbl_status.text = f'Erro: {str(e)}'
            self.lbl_status.color = (0.9, 0.3, 0.3, 1)
    
    def _update_card_rect(self, instance, rect):
        """Atualiza retângulo do card."""
        rect.pos = instance.pos
        rect.size = instance.size
    
    def on_card_click(self, instance, touch, material):
        """Abre detalhes do material."""
        if instance.collide_point(*touch.pos):
            detalhe_screen = self.manager.get_screen('detalhe_material')
            detalhe_screen.set_material(material)
            self.manager.current = 'detalhe_material'
    
    def show_add_material(self, instance):
        """Mostra popup para adicionar material."""
        content = BoxLayout(orientation='vertical', padding=15, spacing=10)
        
        # Campos
        content.add_widget(Label(text='Nome:', color=(1, 1, 1, 1), size_hint_y=None, height=25))
        input_nome = TextInput(multiline=False, size_hint_y=None, height=45)
        content.add_widget(input_nome)
        
        content.add_widget(Label(text='Código:', color=(1, 1, 1, 1), size_hint_y=None, height=25))
        input_codigo = TextInput(multiline=False, size_hint_y=None, height=45)
        content.add_widget(input_codigo)
        
        content.add_widget(Label(text='Quantidade inicial:', color=(1, 1, 1, 1), size_hint_y=None, height=25))
        input_qtd = TextInput(multiline=False, input_type='number', text='0', size_hint_y=None, height=45)
        content.add_widget(input_qtd)
        
        content.add_widget(Label(text='Unidade:', color=(1, 1, 1, 1), size_hint_y=None, height=25))
        input_unidade = TextInput(multiline=False, text='UN', size_hint_y=None, height=45)
        content.add_widget(input_unidade)
        
        # Botões
        btn_box = BoxLayout(size_hint_y=None, height=50, spacing=10)
        
        btn_cancelar = Button(
            text='Cancelar',
            background_color=(0.5, 0.5, 0.5, 1)
        )
        btn_box.add_widget(btn_cancelar)
        
        btn_salvar = Button(
            text='Salvar',
            background_color=(0.2, 0.7, 0.4, 1)
        )
        btn_box.add_widget(btn_salvar)
        
        content.add_widget(btn_box)
        
        popup = Popup(
            title='Novo Material',
            content=content,
            size_hint=(0.9, 0.8)
        )
        
        def salvar(instance):
            nome = input_nome.text.strip()
            if not nome:
                return
            
            try:
                dados = {
                    'nome': nome,
                    'codigo': input_codigo.text.strip() or None,
                    'quantidade': float(input_qtd.text or 0),
                    'unidade': input_unidade.text.strip() or 'UN',
                    'descricao': '',
                    'quantidade_minima': 0,
                    'localizacao': '',
                    'categoria': 'Geral'
                }
                
                self.db.add_material(dados)
                popup.dismiss()
                self.load_materiais()
                
            except Exception as e:
                print(f"[MATERIAIS] Erro ao adicionar: {e}")
        
        btn_cancelar.bind(on_press=popup.dismiss)
        btn_salvar.bind(on_press=salvar)
        
        popup.open()
    
    def on_enter(self):
        """Chamado ao entrar na tela."""
        self.search_input.text = ''
        self.load_materiais()
